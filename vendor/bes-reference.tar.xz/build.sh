#!/usr/bin/env bash
set -euo pipefail

qemu_commit=f671ce11d2a15a58ab752d7cf0b2890c9022c7ba
script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
qemu_src=${MIBAND_QEMU_SRC:-/tmp/miband-qemu-8.2}

bes_cc=${BES_CC:-clang-23}
command -v "$bes_cc" >/dev/null
command -v meson >/dev/null
command -v ninja >/dev/null
pkg-config --exists glib-2.0 pixman-1

if [[ ! -d "$qemu_src/.git" ]]; then
    mkdir -p -- "$qemu_src"
    git -C "$qemu_src" init
    git -C "$qemu_src" remote add origin https://github.com/qemu/qemu.git
    git -C "$qemu_src" fetch --depth 1 origin "$qemu_commit"
    git -C "$qemu_src" checkout --detach FETCH_HEAD
fi

actual_commit=$(git -C "$qemu_src" rev-parse HEAD)
if [[ "$actual_commit" != "$qemu_commit" ]]; then
    printf 'QEMU checkout mismatch: %s (expected %s)\n' "$actual_commit" "$qemu_commit" >&2
    exit 1
fi

python3 "$script_dir/tools/integrate_qemu.py" "$qemu_src"
case "$(uname -s)" in
    MINGW*|MSYS*) python3 "$script_dir/tools/prepare_windows_build.py" "$qemu_src" ;;
esac

if [[ ! -f "$qemu_src/build/build.ninja" || ! -f "$qemu_src/build/meson-private/build.dat" ]]; then
    (
        cd -- "$qemu_src"
        CC="$bes_cc" ./configure \
            --target-list=arm-softmmu \
            --disable-docs --disable-tools --disable-user \
            --disable-guest-agent --disable-slirp \
            --disable-sdl --disable-gtk --disable-curses \
            --disable-opengl --disable-virglrenderer --disable-spice \
            --disable-gnutls \
            --disable-capstone --disable-libnfs --disable-libiscsi \
            --disable-rbd --disable-xen --disable-kvm \
            --disable-tcg-interpreter --disable-werror
    )
fi

# QEMU 8.2's configure writes werror=true for Git checkouts even with
# --disable-werror; Meson reconfigure reads that native-file default again.
if grep -q '^werror = true$' "$qemu_src/build/config-meson.cross"; then
    python3 - "$qemu_src/build/config-meson.cross" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text(encoding='utf-8')
updated = text.replace('werror = true', 'werror = false')
if updated == text:
    raise SystemExit('expected werror setting was not found')
path.write_text(updated, encoding='utf-8')
PY
    bes_meson=$(sed -n 's/^MESON=//p' "$qemu_src/build/config-host.mak")
    "$bes_meson" configure "$qemu_src/build" -Dwerror=false
fi
bes_binary=qemu-system-arm
case "$(uname -s)" in
    MINGW*|MSYS*)
        bes_binary=qemu-system-arm.exe
        python3 "$script_dir/tools/check_native_objects.py" "$qemu_src/build"
        ;;
esac
ninja -C "$qemu_src/build" "$bes_binary"
"$qemu_src/build/$bes_binary" -M help | grep bes1503
printf 'Built: %s/build/%s\n' "$qemu_src" "$bes_binary"
