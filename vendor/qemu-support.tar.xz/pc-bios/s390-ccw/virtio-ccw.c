/*
 * Virtio functionality for CCW devices
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 *
 * Copyright (c) 2013 Alexander Graf <agraf@suse.de>
 * Copyright 2025 IBM Corp.
 *
 * Author(s): Jared Rossi <jrossi@linux.ibm.com>
 */

#include <string.h>
#include "s390-ccw.h"
#include "cio.h"
#include "virtio.h"
#include "virtio-ccw.h"
#include "virtio-scsi.h"
#include "bswap.h"
#include "helper.h"
#include "s390-time.h"

/* virtio spec v1.0 para 4.3.3.2 */
static long kvm_hypercall(unsigned long nr, unsigned long param1,
                          unsigned long param2, unsigned long param3)
{
    register unsigned long r_nr asm("1") = nr;
    register unsigned long r_param1 asm("2") = param1;
    register unsigned long r_param2 asm("3") = param2;
    register unsigned long r_param3 asm("4") = param3;
    register long retval asm("2");

    asm volatile ("diag %%r2,%%r4,0x500"
                  : "=d" (retval)
                  : "d" (r_nr), "0" (r_param1), "r"(r_param2), "d"(r_param3)
                  : "memory", "cc");

    return retval;
}

static int run_ccw(VDev *vdev, int cmd, void *ptr, int len, bool sli)
{
    Ccw1 ccw = {};

    ccw.cmd_code = cmd;
    ccw.cda = (long)ptr;
    ccw.count = len;

    if (sli) {
        ccw.flags |= CCW_FLAG_SLI;
    }

    return do_cio(vdev->schid, vdev->senseid.cu_type, ptr2u32(&ccw), CCW_FMT1);
}

bool virtio_ccw_is_supported(VDev *vdev)
{
    memset(&vdev->senseid, 0, sizeof(vdev->senseid));

    /*
     * Run sense id command.
     * The size of the senseid data differs between devices (notably,
     * between virtio devices and dasds), so specify the largest possible
     * size and suppress the incorrect length indication for smaller sizes.
     */
    if (run_ccw(vdev, CCW_CMD_SENSE_ID, &vdev->senseid, sizeof(vdev->senseid),
                true)) {
        return false;
    }

    vdev->dev_type = vdev->senseid.cu_model;

    if (vdev->senseid.cu_type == 0x3832) {
        switch (vdev->dev_type) {
        case VIRTIO_ID_BLOCK:
        case VIRTIO_ID_SCSI:
        case VIRTIO_ID_NET:
            return true;
        default:
            return false;
        }
    }
    return false;
}

int drain_irqs_ccw(SubChannelId schid)
{
    Irb irb = {};
    int r = 0;

    while (1) {
        /* FIXME: make use of TPI, for that enable subchannel and isc */
        if (tsch(schid, &irb)) {
            /* Might want to differentiate error codes later on. */
            if (irb.scsw.cstat) {
                r = -EIO;
            } else if (irb.scsw.dstat != 0xc) {
                r = -EIO;
            }
            return r;
        }
    }
}

long virtio_ccw_notify(SubChannelId schid, int vq_idx, long cookie)
{
    return kvm_hypercall(KVM_S390_VIRTIO_CCW_NOTIFY, *(u32 *)&schid,
                         vq_idx, cookie);
}

int virtio_ccw_reset(VDev *vdev)
{
    return run_ccw(vdev, CCW_CMD_VDEV_RESET, NULL, 0, false);
}

int virtio_ccw_setup(VDev *vdev)
{
    int i, cfg_size = 0;
    uint8_t status;
    struct VirtioFeatureDesc {
        uint32_t features;
        uint8_t index;
    } __attribute__((packed)) feats;

    if (!virtio_ccw_is_supported(vdev)) {
        puts("Virtio unsupported for this device ID");
        return -ENODEV;
    }
    /* device ID has been established now */

    vdev->config.blk.blk_size = 0; /* mark "illegal" - setup started... */
    vdev->guessed_disk_nature = VIRTIO_GDN_NONE;

    virtio_reset(vdev);

    status = VIRTIO_CONFIG_S_ACKNOWLEDGE;
    if (run_ccw(vdev, CCW_CMD_WRITE_STATUS, &status, sizeof(status), false)) {
        puts("Could not write ACKNOWLEDGE status to host");
        return -EIO;
    }

    switch (vdev->dev_type) {
    case VIRTIO_ID_NET:
        vdev->nr_vqs = 2;
        vdev->cmd_vr_idx = 0;
        cfg_size = sizeof(vdev->config.net);
        break;
    case VIRTIO_ID_BLOCK:
        vdev->nr_vqs = 1;
        vdev->cmd_vr_idx = 0;
        cfg_size = sizeof(vdev->config.blk);
        break;
    case VIRTIO_ID_SCSI:
        vdev->nr_vqs = 3;
        vdev->cmd_vr_idx = VR_REQUEST;
        cfg_size = sizeof(vdev->config.scsi);
        break;
    default:
        puts("Unsupported virtio device");
        return -ENODEV;
    }

    status |= VIRTIO_CONFIG_S_DRIVER;
    if (run_ccw(vdev, CCW_CMD_WRITE_STATUS, &status, sizeof(status), false)) {
        puts("Could not write DRIVER status to host");
        return -EIO;
    }

    /* Feature negotiation */
    for (i = 0; i < ARRAY_SIZE(vdev->guest_features); i++) {
        feats.features = 0;
        feats.index = i;
        if (run_ccw(vdev, CCW_CMD_READ_FEAT, &feats, sizeof(feats), false)) {
            puts("Could not get features bits");
            return -EIO;
        }

        vdev->guest_features[i] &= bswap32(feats.features);
        feats.features = bswap32(vdev->guest_features[i]);
        if (run_ccw(vdev, CCW_CMD_WRITE_FEAT, &feats, sizeof(feats), false)) {
            puts("Could not set features bits");
            return -EIO;
        }
    }

    if (run_ccw(vdev, CCW_CMD_READ_CONF, &vdev->config, cfg_size, false)) {
        puts("Could not get virtio device configuration");
        return -EIO;
    }

    for (i = 0; i < vdev->nr_vqs; i++) {
        VqInfo info = {
            .queue = (unsigned long long) virtio_get_ring_area(i),
            .align = KVM_S390_VIRTIO_RING_ALIGN,
            .index = i,
            .num = 0,
        };
        VqConfig config = {
            .index = i,
            .num = 0,
        };

        if (run_ccw(vdev, CCW_CMD_READ_VQ_CONF, &config, sizeof(config),
                false)) {
            puts("Could not get virtio device VQ config");
            return -EIO;
        }
        info.num = config.num;
        vring_init(&vdev->vrings[i], &info);
        if (run_ccw(vdev, CCW_CMD_SET_VQ, &info, sizeof(info), false)) {
            puts("Cannot set VQ info");
            return -EIO;
        }
    }

    status |= VIRTIO_CONFIG_S_DRIVER_OK;
    if (run_ccw(vdev, CCW_CMD_WRITE_STATUS, &status, sizeof(status), false)) {
        puts("Could not write DRIVER_OK status to host");
        return -EIO;
    }

    return 0;
}

static bool find_ccw_net_dev(Schib *schib, int dev_no)
{
    int i, r;

    for (i = 0; i < 0x10000; i++) {
        net_schid.sch_no = i;
        r = stsch_err(net_schid, schib);
        if (r == 3 || r == -EIO) {
            break;
        }
        if (!schib->pmcw.dnv) {
            continue;
        }
        enable_subchannel(net_schid);
        if (!virtio_is_supported(virtio_get_device())) {
            continue;
        }
        if (virtio_get_device_type() != VIRTIO_ID_NET) {
            continue;
        }
        if (dev_no < 0 || schib->pmcw.dev == dev_no) {
            return true;
        }
    }

    return false;
}

bool virtio_ccw_net_setup(void)
{
    Schib schib;
    int ssid;
    bool found = false;
    uint16_t dev_no;

    /*
     * We unconditionally enable mss support. In every sane configuration,
     * this will succeed; and even if it doesn't, stsch_err() can deal
     * with the consequences.
     */
    enable_mss_facility();

    if (have_iplb || store_iplb(iplb)) {
        IPL_assert(iplb->pbt == S390_IPL_TYPE_CCW, "IPL_TYPE_CCW expected");
        dev_no = iplb->ccw.devno;
        debug_print_int("device no. ", dev_no);
        net_schid.ssid = iplb->ccw.ssid & 0x3;
        debug_print_int("ssid ", net_schid.ssid);
        found = find_ccw_net_dev(&schib, dev_no);
    } else {
        for (ssid = 0; ssid < 0x3; ssid++) {
            net_schid.ssid = ssid;
            found = find_ccw_net_dev(&schib, -1);
            if (found) {
                break;
            }
        }
    }

    return found;
}
