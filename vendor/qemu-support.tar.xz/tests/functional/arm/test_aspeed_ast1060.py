#!/usr/bin/env python3
#
# Functional test that boots the ASPEED SoCs with firmware
#
# Copyright (C) 2025 ASPEED Technology Inc
#
# SPDX-License-Identifier: GPL-2.0-or-later

from aspeed import AspeedTest
from qemu_test import Asset, exec_command_and_wait_for_pattern


class AST1060Machine(AspeedTest):
    ASSET_ASPEED_AST1060_PROT_3_07 = Asset(
        ('https://github.com/AspeedTech-BMC'
         '/aspeed-zephyr-project/releases/download/v03.07'
         '/ast1060_prot_v03.07.tgz'),
         '55a7f51f0b77051a0ef2ada993a16c5033768e1b8e8be3babfc52c303eecd07f')

    def test_arm_ast1060_prot_3_07(self):
        self.set_machine('ast1060-evb')

        kernel_name = "ast1060_prot/zephyr.bin"
        kernel_file = self.archive_extract(
            self.ASSET_ASPEED_AST1060_PROT_3_07, member=kernel_name)

        self.vm.set_console()
        self.vm.add_args('-kernel', kernel_file, '-nographic')
        self.vm.launch()
        self.wait_for_console_pattern("Booting Zephyr OS")
        exec_command_and_wait_for_pattern(self, "help",
                                          "Available commands")

    def test_arm_ast1060_otp_blockdev_device(self):
        self.vm.set_machine("ast1060-evb")

        kernel_name = "ast1060_prot/zephyr.bin"
        kernel_file = self.archive_extract(self.ASSET_ASPEED_AST1060_PROT_3_07,
                                           member=kernel_name)
        otp_img = self.generate_otpmem_image()

        self.vm.set_console()
        self.vm.add_args(
            "-kernel", kernel_file,
            "-blockdev", f"driver=file,filename={otp_img},node-name=otp",
            "-global", "aspeed-otp.drive=otp",
        )
        self.vm.launch()
        self.wait_for_console_pattern("Booting Zephyr OS")

if __name__ == '__main__':
    AspeedTest.main()
