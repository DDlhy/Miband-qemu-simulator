# Default configuration for hexagon-softmmu

# Uncomment the following lines to disable these optional devices:

# Boards are selected by default, uncomment to keep out of the build.
# CONFIG_HEX_VIRT=y
# CONFIG_HEX_DSP=y
